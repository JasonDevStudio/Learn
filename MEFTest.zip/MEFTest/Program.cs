﻿using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Loader;
using MEFLib;
using MEFTest;

class Program
{ 
    [Import]
    public ExportFactory<ISerializationService> SerializationServiceFactory { get; set; }
    
    static void Main(string[] args)
    {
        // AppDomain.CurrentDomain.AssemblyResolve += (sender, args) =>
        // {
        //    
        //     
        //     string assemblyFolder = Path.GetDirectoryName(@"C:\Users\yaoji\RiderProjects\MEFTest\MEFImpl\bin\Debug\net8.0\MEFImpl.dll");
        //     string assemblyName = new AssemblyName(args.Name).Name;
        //     string assemblyPath = Path.Combine(assemblyFolder, assemblyName + ".dll");
        //     if (File.Exists(assemblyPath))
        //     {
        //         return AssemblyLoadContext.Default.LoadFromAssemblyPath(assemblyPath);
        //         //return Assembly.LoadFrom(assemblyPath);
        //     }
        //     return null;
        // };

        var program = new Program();
        MEFUtil.InitializeMEF().ComposeParts(program);
         
        var mefProgram1 = new MEFTest.MEFProgram(program.SerializationServiceFactory); 
        mefProgram1.SerializationService.SerializeToFile("test.txt", new { Name = "John", Age = 30 });
        Console.WriteLine("Serialized object to file 'test.txt'.");
        
        var mefProgram2 = new MEFTest.MEFProgram(program.SerializationServiceFactory); 
        mefProgram2.SerializationService.SerializeToFile("test.txt", new { Name = "John", Age = 30 });
        Console.WriteLine("Serialized object to file 'test.txt'.");

        var isequals = Object.ReferenceEquals(mefProgram1.SerializationService, mefProgram2.SerializationService);
        Console.WriteLine($"mefProgram1.SerializationService 与 mefProgram2.SerializationService 是否为同一实例：{isequals}");
    } 
}