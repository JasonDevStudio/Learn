using System.ComponentModel.Composition.Hosting;
using System.Runtime.Loader;
using MEFLib;

namespace MEFTest
{
    public static class MEFUtil
    {
        private static CompositionContainer _container = null;
        
        public static CompositionContainer InitializeMEF()
        {
            if (_container != null)
                return _container;
            
            var catalog = new AggregateCatalog();
            catalog.Catalogs.Add(new AssemblyCatalog(typeof(Program).Assembly));
            catalog.Catalogs.Add(new AssemblyCatalog(typeof(ISerializationService).Assembly));
            catalog.Catalogs.Add(new AssemblyCatalog(@"C:\Users\yaoji\RiderProjects\MEFTest\MEFImpl\bin\Debug\net8.0\MEFImpl.dll"));
            AssemblyLoadContext.Default.LoadFromAssemblyPath(@"C:\Users\yaoji\RiderProjects\MEFTest\MEFImpl\bin\Debug\net8.0\MEFImpl.dll");
            _container = new CompositionContainer(catalog);
            return _container;
        }
    }
}