using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Runtime.Loader;
using MEFLib;

namespace MEFTest
{
    public class MEFProgram
    { 
        public ISerializationService SerializationService { get; set; }
 
        public MEFProgram(ExportFactory<ISerializationService> serializationServiceFactory)
        {
            // 获取一个新的 ISerializationService 实例
            SerializationService = serializationServiceFactory.CreateExport().Value;
        }
        
        public MEFProgram()
        { 
            MEFUtil.InitializeMEF().ComposeParts(this);
            // 获取一个新的 ISerializationService 实例
            SerializationService = MEFUtil.InitializeMEF().GetExportedValue<ISerializationService>();
        }
    }
}