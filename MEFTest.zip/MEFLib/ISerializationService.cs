﻿namespace MEFLib;

public interface ISerializationService
{
    void SerializeToFile(string filePath, object data);
}