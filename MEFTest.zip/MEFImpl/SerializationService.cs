﻿using System.ComponentModel.Composition;
using MEFLib;
using Newtonsoft.Json;

namespace MEFImpl;

[Export(typeof(ISerializationService))]
[PartCreationPolicy(CreationPolicy.NonShared)] // 添加这一行
public class SerializationService : ISerializationService
{
    public void SerializeToFile(string filePath, object data)
    {
        var json = JsonConvert.SerializeObject(data);
        File.WriteAllText(filePath,json);
    }
}